# jweixin-module

微信JS-SDK

## 安装

### NPM

```shell
npm install jweixin-module --save
```

### UMD

```http
https://unpkg.com/jweixin-module/out/index.js
```

## 使用

```js
var wx = require('jweixin-module')
wx.ready(function(){
    // TODO
});
```

## 完整API

>[微信JS-SDK说明文档](https://mp.weixin.qq.com/wiki?t=resource/res_main&id=mp1421141115)
