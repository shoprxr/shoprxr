<template>
	<view class="address-form">
		<form @submit="formSubmit">
			<view class="bg-white p-0-30 f30">
				<view class="d-b-c p-30-0 border-b">
					<text class="key-name">会员ID</text>
					<view class="d-e-c">
						<text class="mr20">{{userInfo.user_id}}</text>
					</view>
				</view>
				<view class="d-b-c p-30-0 border-b">
					<text class="key-name">昵称</text>
					<view class="d-e-c">
						<text class="mr20">{{userInfo.nickName}}</text>
					</view>
				</view>
				<view class="d-b-c p-30-0">
					<text class="key-name">手机号码</text>
					<view class="d-e-c" v-if="userInfo.mobile">
						<text class="mr20">{{userInfo.mobile}}</text>
					</view>
					<view class="d-e-c" v-if="!userInfo.mobile" @click="gotoBind">
						<text class="mr20">未绑定</text>
						<text class="iconfont icon-jiantou"></text>
					</view>
				</view>
			</view>
		</form>
		
	</view>
</template>

<script>

export default {
	components: {
	},
	data() {
		return {
			userInfo:{}
		};
	},
	onShow() {
    this.setGlobalColor()
		/*获取个人中心数据*/
		this.getData();
	},
	methods: {
		/*获取数据*/
		getData() {
			let self = this;
			uni.showLoading({
				title: '加载中'
			});
			self._get('user.index/setting', {}, function(res) {
				self.userInfo = res.data.userInfo;
				uni.hideLoading();
			});
		},
		gotoBind(){
			uni.navigateTo({
				url: '/pages/login/bindmobile'
			});
		},
	}
};
</script>

<style>
.address-form .key-name {
	width: 200rpx;
}
.address-form .btn-red{
	height: 88rpx;
	line-height: 88rpx;
	border-radius: 44rpx;
	box-shadow: 0 8rpx 16rpx 0 rgba(226,35,26,.6);
}
</style>
