<template>
	<view class="address-form">
		<form @submit="formSubmit">
			<view class="bg-white p-0-30 f30">
				<view class="d-b-c p-30-0 border-b">
					<text class="key-name">头像</text>
					<view class="d-e-c">
						<image mode="aspectFit" :src="userInfo.avatarUrl"></image>
					</view>
				</view>
				<view class="d-b-c p-30-0 border-b" @click="gotoUserName">
					<text class="key-name">昵称</text>
					<view class="d-e-c">
						<text class="mr20">{{userInfo.nickName}}</text>
						<text class="iconfont icon-jiantou"></text>
					</view>
				</view>
				<view class="d-b-c p-30-0 border-b">
					<text class="key-name">性别</text>
					<view class="d-e-c">
						<text class="mr20">{{userInfo.gender == 2 ? '未知' : (userInfo.gender == 1 ? '男' : '女')}}</text>
					</view>
				</view>
				<view class="d-b-c p-30-0 border-b">
					<text class="key-name">生日</text>
					<view class="d-e-c">
						<text class="mr20">{{userInfo.birthday == null ? '' : userInfo.birthday}}</text>
					</view>
				</view>
				<view class="d-b-c p-30-0 border-b">
					<text class="key-name">手机</text>
					<view class="d-e-c">
						<!-- <input class="uni-input" type="number" :placeholder="phone" style="margin-right: -130rpx;" v-model="phone"/> -->
						<text class="mr20">{{userInfo.mobile}}</text>
					</view>
					<!-- <view class="d-e-c" v-if="!phone" @click="gotoBind">
						<text class="mr20">未绑定</text>
						<text class="iconfont icon-jiantou"></text>
					</view> -->
				</view>
				<view class="d-b-c p-30-0" @click="gotoUserPwd">
					<text class="key-name">密码</text>
					<view class="d-e-c">
						<text class="iconfont icon-jiantou"></text>
					</view>
				</view>
			</view>
			<!-- #ifdef H5 -->
			<view class="btns p30"><button type="default" @click="LoginOut">退出登录</button></view>
			<!-- #endif -->
		</form>

	</view>
</template>

<script>

export default {
	components: {
	},
	data() {
		return {
			userInfo:{},
		};
	},
	onLoad() {
		this.getData();
	},
	onShow() {
    this.setGlobalColor()
		this.getData();
	},
	methods: {
		gotoUserName(){
			let user_name = this.userInfo.nickName
			uni.navigateTo({
				url: '/user/pages/user/info?data='+user_name+'&type=1'
			});
		},
		gotoUserPwd(){
			uni.navigateTo({
				url: '/user/pages/user/info?type=2'
			});
		},
		getData(){
			let self = this;
			uni.showLoading({
				title: '加载中'
			});
			self._get('user.index/detail', {}, function(res) {

				self.userInfo = res.data.userInfo;
				uni.hideLoading();
			});
		},
		// h5退出登录
		LoginOut(){
			uni.setStorageSync('token', '');
			uni.setStorageSync('user_id', '');
			uni.navigateTo({
			    url: '/user/pages/user/login'
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.address-form .key-name {
	width: 200rpx;
}
.address-form .btn-red{
	height: 88rpx;
	line-height: 88rpx;
	border-radius: 44rpx;
	box-shadow: 0 8rpx 16rpx 0 rgba(226,35,26,.6);
}
.save_btn{
	width: 100%;
	height: 45px;
	line-height: 45px;
	-webkit-border-radius: 0;
	border-radius: 0;
	position: fixed;
	bottom: 0;
	display: flex;
	-webkit-box-pack: end;
	justify-content: center;
	align-items: center;
}
.d-e-c image{
	width: 100rpx;
	height: 100rpx;
	border-radius: 55rpx;
}
.mr20{
	color: #C5C5C5;
}
.p30{
	margin-top: 100rpx;
}
.btns button {
	height: 90rpx;
	line-height: 90rpx;
	font-size: 34rpx;
	border-radius: 45rpx;
	background: #e4dddd;
	color: #ffffff;
}
</style>
