<template>
	<view class="login-container">

		<view class="wechatapp" v-if="has_referee_info">
			<view class="header">
				<image :src="user_info.avatarUrl" style="width: 200rpx;height: 300rpx;"></image>
			</view>
			<view>{{user_info.nickName}}</view>
			<view>{{user_info.user_id}}</view>
		</view>
		<view class="auth-subtitle">为了为您提供更优质的服务，我们需要为你绑定上级</view>
		<view class="login-btn">
			<button  class="btn-normal" @click="comfirmRefereeId">确定</button>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				referee_id:0,
				has_referee_info:false,
				user_info:{}
			}
		},
		onLoad(e) {
			this.referee_id = e.referee_id?e.referee_id:0;
		},
		onShow(e) {
      		this.setGlobalColor()

			this.getData();
		},
		methods: {
			comfirmRefereeId() {
				uni.reLaunch({
					url: '/pages/index/index'
				})
			},
			getData() {
				let self = this;
				let timestamp = new Date().getTime();
				uni.showLoading({
					title: '加载中,请稍等'
				});
				let pathurl = "/pages/index/index?t="+timestamp;
				self._get('index/inviter', {}, function(res) {
					uni.setStorageSync('referee_id',self.referee_id);
					if(res.code==1){
						self.user_info = res.data.agentUser;
						self.has_referee_info = true;

					}else if(res.code==100){
						uni.redirectTo({
							url:'/user/pages/user/reg'
						})
					}else{
						uni.showModal({
							title:"提示",
							content:res.msg,
							showCancel:false,
							success(res) {
								if(res.confirm){
									uni.reLaunch({
										url: '/pages/index/index'
									})
								}
							}
						})
					}
					uni.hideLoading();
				});
			}
		}
	}
</script>

<style>
	.login-container {
		padding: 30rpx;
	}

	.wechatapp {
		padding: 80rpx 0 48rpx;
		border-bottom: 1rpx solid #e3e3e3;
		margin-bottom: 72rpx;
		text-align: center;
	}

	.wechatapp .header {
		width: 190rpx;
		height: 190rpx;
		border: 2px solid #fff;
		margin: 0rpx auto 0;
		border-radius: 50%;
		overflow: hidden;
		box-shadow: 1px 0px 5px rgba(50, 50, 50, 0.3);
	}

	.auth-title {
		color: #585858;
		font-size: 34rpx;
		margin-bottom: 40rpx;
	}

	.auth-subtitle {
		color: #888;
		margin-bottom: 88rpx;
		font-size: 28rpx;
	}

	.login-btn {
		padding: 0 20rpx;
	}

	.login-btn button {
		height: 88rpx;
		line-height: 88rpx;
		background: #04be01;
		color: #fff;
		font-size: 30rpx;
		border-radius: 999rpx;
		text-align: center;
	}

	.no-login-btn {
		margin-top: 20rpx;
		padding: 0 20rpx;
	}

	.no-login-btn button {
		height: 88rpx;
		line-height: 88rpx;
		background: #dfdfdf;
		color: #fff;
		font-size: 30rpx;
		border-radius: 999rpx;
		text-align: center;
	}
	.wechatapp .search-referee{
		width: 10%;
		border-left: 1rpx #e3e3e3 solid;
	}
</style>
