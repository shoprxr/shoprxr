<template>
	<view class="user-index" v-if="!loadding">
		<!-- <uni-load-more :loadingType="1"> -->
		<!--个人信息-->
		<view class="user-header" :style="[bgcColor]">
			<view class="user-header-inner" @click="editUserInfo">
				<view class="user-info" >
					<view class="photo"><image :src="detail.avatarUrl" mode="aspectFill" ></image></view>
					<view class="info">
						<view class="name">{{ detail.nickName }}</view>
						<view class="tel d-s-c">
							<text class="f24">ID:{{ detail.user_id }}</text>
							<text class="ml20 grade" v-if="detail.grade_id > 0">{{ detail.grade.name }}</text>
						</view>
						<view class="tel d-s-c" v-if="detail.expire_date_day_text && !detail.grade.is_default">
							<text class="f24">到期时间: 至 {{ detail.expire_date_day_text }}</text>
						</view>
						<view v-if="code.code_status == 1">{{code.code_desc}}:{{code.user_code}}</view>
					</view>
				</view>
				<view v-if="sign.is_open == 1" class="sign-box d-c-c" :style="[textColor2]" @click.stop="gotoPage('/plus/pages/signin/signin')">
					<text class="icon iconfont icon-libao" :style="[textColor(false)]"></text>
					<text class="ml10">签到有礼</text>
				</view>
			</view>

			<!--我的订单-->
			<view class="my-order">
				<view class="group-hd border-b-e">
					<view class="left"><text class="min-name">我的订单</text></view>
				</view>
				<view class="d-b-c">
					<view class="item" @click="gotoPage('/main/pages/order/myorder/myorder?dataType=all')">
						<view class="icon-box"><span class="icon iconfont icon-quanbudingdan" :style="[textColor(true)]"></span></view>
						<text>全部订单</text>
					</view>
					<view class="item" @click="gotoPage('/main/pages/order/myorder/myorder?dataType=payment')">
						<view class="icon-box pr">
							<span class="icon iconfont icon-icon" :style="[textColor(true)]"></span>
							<text class="dot d-c-c" v-if="orderCount.payment != null && orderCount.payment > 0">{{ orderCount.payment }}</text>
						</view>
						<text>待付款</text>
					</view>
					<view class="item" @click="gotoPage('/main/pages/order/myorder/myorder?dataType=received')">
						<view class="icon-box pr">
							<span class="icon iconfont icon-daishouhuo" :style="[textColor(true)]"></span>
							<text class="dot d-c-c" v-if="orderCount.received != null && orderCount.received > 0">{{ orderCount.received }}</text>
						</view>
						<text>待收货</text>
					</view>
					<view class="item" @click="gotoPage('/main/pages/order/refund/index/index')">
						<view class="icon-box pr">
							<span class="icon iconfont icon-tuikuan" :style="[textColor(true)]"></span>
							<text class="dot d-c-c" v-if="orderCount.refund != null && orderCount.refund > 0">{{ orderCount.refund }}</text>
						</view>
						<text>售后</text>
					</view>
				</view>
			</view>
		</view>

		<!--我的资产-->
		<view class="my-assets d-b-c">
			<view class="list d-a-c flex-1 mr30">
				<view class="item d-c-c d-c" @click="gotoPage('/user/pages/my-wallet/my-wallet')">
					<view class="fb f30">{{ detail.balance }}</view>
					<text class="pt10 f24 gray3">{{balance_text}}</text>
				</view>
				<view class="item d-c-c d-c" @click="gotoPage('/user/pages/points/points')">
					<view class="fb f30">{{ detail.points }}</view>
					<text class="pt10 f24 gray3">{{setting.points_name}}</text>
				</view>
				<!-- <view class="item d-c-c d-c" @click="gotoPage('/user/pages/my-coupon/my-coupon')">
					<view class="fb f30">{{ coupon }}</view>
					<text class="pt10 f24 gray3">优惠券</text>
				</view> -->
			</view>
			<!-- <view class="my-wallet d-c-c d-c" @click="gotoPage('/user/pages/my-wallet/my-wallet')">
					<view class="icon-box">
						<text class="icon iconfont icon-qianbao"></text>
					</view>
					<text class="f24 gray6">我的钱包</text>
				</view> -->
		</view>

		<!--菜单-->
		<view class="menu-wrap" v-if="diymenus == 1&&!menus">
			<diy :diyItems="menus"></diy>
		</view>

		<view v-else-if="diymenus == 1" scroll-y="true" class="scroll-Y"  >
			<diy :diyItems="items"></diy>
		</view>
		<view class="menu-wrap" v-else>
			<!-- <view class="group-hd p-0-20 border-b-e">
					<view class="left">
						<text class="min-name">基础入口</text>
					</view>
				</view> -->
			<view class="group-bd">
				<view :class="'item ' + item.icon + '-box'" v-for="(item, index) in menus" :key="index" @click="gotoPage(item.path)">
					<view class="icon-round d-c-c"><text :class="'icon iconfont ' + item.icon"></text></view>
					<text class="name">{{ item.name }}</text>
				</view>
			</view>
		</view>

		<!--邀请有礼-->
		<!-- <view class="invite-box p20" @click="gotoPage('/user/pages/invite/invite')">
				<image src="http://imgh5.y01.cn/20210606232139f37ed9784.jpg" mode="widthFix"></image>
			</view> -->

		<!--推荐-->
		<view class="mt30">
			<recommendProduct v-if="is_recommend" :recommendData="recommendData"></recommendProduct>
		</view>
		<!-- <view class="friend">
			<text class="text">我的圈子</text>
			<image class="img" src="" mode=""></image>
		</view> -->
		<Tabbar></Tabbar>
		<!-- </uni-load-more> -->
	</view>
</template>

<script>
import uniLoadMore from '@/components/uni-load-more.vue';
import recommendProduct from '@/components/recommendProduct/recommendProduct.vue';
import Tabbar from '@/components/tabbar/tabbar.vue';
export default {
	components: {
		uniLoadMore,
		recommendProduct,
		Tabbar
	},
	data() {
		return {
			/*是否推荐*/
			is_recommend: false,
			/*推荐数据*/
			recommendData: {},
			/*签到数据*/
			sign: {},
			/*是否加载完成*/
			loadding: true,
			indicatorDots: true,
			autoplay: true,
			interval: 2000,
			duration: 500,
			/*菜单*/
			menus: [],
			detail: {
				balance: 0,
				points: 0,
				grade: {
					name: ''
				},
			},
			orderCount: {},
			coupon: 0,
			setting:{},
			diymenus:0,
			// 编码
			code:{
				code_status:0,
				code_code_desc:'',
				user_code : ''
			},
			items:[],
			balance_text:'余额',
		};
	},
	onShow() {
    // 设置全局颜色
    this.setGlobalColor()

    uni.showLoading({
			title: '加载中'
		});
		this.init();
		/*获取个人中心数据*/
		this.getData();
	},
  computed: {
    active() {
      return Object.assign(this.setBackgroundColor(), this.setColor())
    },
    bgcColor() {
      return this.setBackgroundColor()
    },
    textColor() {
      return flag => {
        flag = !!flag
        return this.setColor(flag)
      }
    },
    textColor2() {
      return Object.assign(this.setColor(), {border: '1px solid ' + this.getTextColor()})
    }
  },
	methods: {
		/*初始化*/
		init() {
			let _this = this;
			uni.getSystemInfo({
				success(res) {
					_this.phoneHeight = res.windowHeight;
				}
			});
		},

		/*获取数据*/
		getData() {
			let self = this;
			self._get('user.index/detail', {}, function(res) {


				if(res.data.getPhone){

					uni.navigateTo({
						url: "/pages/login/bindmobile"
					});
					return;
				}


				self.detail = res.data.userInfo;
				self.is_recommend = res.data.is_recommend;
				self.recommendData = res.data.recommendData;
				self.sign = res.data.sign;
				self.coupon = res.data.coupon;
				self.orderCount = res.data.orderCount;
				self.menus = res.data.menus;
				self.setting=res.data.setting;
				self.diymenus = res.data.diymenus;
				self.loadding = false;
				self.code = res.data.code_info;
				self.balance_text =res.data.balance_text;
				self.items  =res.data.items.items;
				self.pagesetting  =res.data.items.page;
				uni.hideLoading();
			});
		},

		editUserInfo(){
			uni.navigateTo({
				url: '/user/pages/user/edit'
			});
		},
		/*跳转页面*/
		gotoPage(path) {
			uni.navigateTo({
				url: path
			});
		}
	}
};
</script>

<style>
.user-header {
	position: relative;
	background: #e2231a;
}
.user-header .user-header-inner{position: relative;
padding: 30rpx 30rpx 120rpx;
display: flex;
	justify-content: space-between;
	align-items: center;
overflow: hidden;}
.user-header .user-header-inner::after,
.user-header .user-header-inner::before {
	display: block;
	content: '';
	position: absolute;
	border-radius: 50%;
	z-index: 0;
}
.user-header .user-header-inner::after {
	width: 400rpx;
	height: 400rpx;
	right: -100rpx;
	bottom: -200rpx;
	background-image: radial-gradient(90deg, rgba(255, 255, 255, 0.2) 10%, rgba(255, 255, 255, 0));
}

.user-header .user-header-inner::before {
	width: 200rpx;
	height: 200rpx;
	left: -60rpx;
	top: -20rpx;
	background-image: radial-gradient(-90deg, rgba(255, 255, 255, 0.2) 10%, rgba(255, 255, 255, 0));
}

.user-header .user-info {
	display: flex;
	justify-content: flex-start;
	align-items: center;
}

.user-header .photo,
.user-header .photo image {
	width: 120rpx;
	height: 120rpx;
	border-radius: 50%;
}

.user-header .photo {
	border: 4rpx solid #ffffff;
}

.user-header .info {
	padding-left: 20rpx;
	box-sizing: border-box;
	overflow: hidden;
	color: #ffffff;
}

.user-header .info .name {
	font-weight: bold;
	font-size: 30rpx;
}

.user-header .info .tel {
	font-size: 26rpx;
}

.user-header .info .grade {
	display: block;
	padding: 0 16rpx;
	height: 40rpx;
	line-height: 36rpx;
	border-radius: 20rpx;
	background: rgba(0, 0, 0, 0.2);
	color: #ffc670;
}

.user-header .sign-box {
	position: absolute;
	right: 20rpx;
	padding: 0 10rpx;
	height: 50rpx;
	border: 1px solid #ffe300;
	border-radius: 25rpx;
	font-size: 24rpx;
	color: #ffe300;
	z-index: 10;
}
.user-header .sign-box .iconfont {
	color: #ffe300;
}

.user-header .my-order {
	position: absolute;
	padding: 0 30rpx;
	height: 240rpx;
	right: 30rpx;
	bottom: -150rpx;
	left: 30rpx;
	box-sizing: border-box;
	border-radius: 16rpx;
	box-shadow: 0 0 6rpx 0 rgba(0, 0, 0, 0.1);
	background: #ffffff;
	z-index: 10;
}

.my-order .item {
	display: flex;
	padding: 20rpx 0;
	flex-direction: column;
	justify-content: center;
	align-items: center;
	font-size: 26rpx;
}

.my-order .icon-box,
.my-assets .icon-box {
	width: 60rpx;
	height: 60rpx;
}

.my-order .icon-box .iconfont,
.my-assets .icon-box .iconfont {
	font-size: 50rpx;
	color: #333333;
}

.my-order .icon-box .dot {
	position: absolute;
	top: 0;
	left: 30rpx;
	height: 30rpx;
	min-width: 30rpx;
	padding: 4rpx;
	border-radius: 20rpx;
	font-size: 20rpx;
	background: #f00808;
	color: #ffffff;
}

.my-assets {
	margin-top: 180rpx;
	padding: 30rpx;
	background: #ffffff;
}

.my-wallet {
	position: relative;
	width: 200rpx;
	border-left: 1px solid #dddddd;
}

.my-wallet::after {
	position: absolute;
	display: block;
	content: '';
	left: 0;
	border: 8rpx solid transparent;
	border-left-color: #dddddd;
}

.menu-wrap {
	margin-top: 30rpx;
	background: #ffffff;
}
.menu-wrap .group-bd {
	display: flex;
	justify-content: flex-start;
	align-items: flex-start;
}
.menu-wrap .item {
	display: flex;
	justify-content: center;
	align-items: center;
	flex-direction: column;
	width: 190rpx;
	height: 150rpx;
	font-size: 24rpx;
}
.menu-wrap .item.icon-dizhi1-box .icon-round {
	background-image: linear-gradient(135deg, #67b4e2 10%, #356dce 70%, #5c8fe8 90%);
}
.menu-wrap .item.icon-youhuiquan1-box .icon-round {
	background-image: linear-gradient(135deg, #e87ea4 10%, #ff268a 70%, #fe0d76 90%);
}
.menu-wrap .item.icon-youhuiquan--box .icon-round {
	background-image: linear-gradient(135deg, #ff5a30 10%, #ff2b3c 70%, #ff1740 90%);
}
.menu-wrap .item.icon-fenxiao1-box .icon-round {
	background-image: linear-gradient(135deg, #7ceeba 10%, #1ed2b7 70%, #17c0ad 90%);
}
.menu-wrap .item.icon-kanjia-box .icon-round {
	background-image: linear-gradient(135deg, #f2a904 10%, #f27d04 70%, #eaa031 90%);
}
.menu-wrap .icon-round {
	width: 60rpx;
	height: 60rpx;
	background: red;
	border-radius: 50%;
	color: #ffffff;
}
.menu-wrap .item .iconfont {
	font-size: 40rpx;
	color: #ffffff;
}
.menu-wrap .item .name {
	margin-top: 10rpx;
}
.friend {
	margin-top: 30rpx;
	background: #ffffff;
}

.friend .text{
	margin-top: 22rpx;
	margin-left: 30rpx;
	font-size: 32rpx;
}

.friend .img{
	margin-top: 12rpx;
	margin-left: 30rpx;
	width: 690rpx;
	height: 220rpx;
	background: #000000;
}


</style>
