<template>
	<view>
		<view class="address-list bg-white">
			<view class="address p30 d-s-c border-b-e" v-for="(item,index) in storeList" :key="index">
			
				<view class="info flex-1">
					<view class="user f34 store_name">
						<text>{{item.store_name}}</text>
					</view>
					<view class="pt10 user f30 gray6" style="z-index:100">
						<text  @click="takePhone(item.phone)">{{item.phone}} <text style="color:#007AFF;font-size:13px ;padding-left: 10px;">拨打</text></text>
					</view>
					<view class="pt10 f24 gray6 " style="display: inline-block;white-space:normal; width:70%"  @click="showAddress(item.latitude,item.longitude,item.address)">
						<text > {{item.region.province}}{{item.region.city}}{{item.region.region}}{{item.address}}<text style="color:#007AFF;font-size:13px ;padding-left: 10px;">导航</text></text>
					</view>
					<view v-if="is_select" class="pt10 f24 gray6 fr select_store" @click="onSelectedStore(item.store_id)">选择</view>
					<view>
						<text class="iconfont icon-dingwei"></text>
						<text>{{item.distance_unit}}</text>
					</view>
					<!-- 选中状态 -->
					<view v-if="item.store_id == selectedId" class="shop-item__right">
						<text class="iconfont icon-iconfontduihaocopy"></text>
					</view>
				</view>
			</view>
			<!-- 无数据提供的页面 -->
			<view v-if="!isLoading && !storeList.length">
				<view class="yoshop-notcont">
					<text class="iconfont icon-wushuju"></text>
					<text class="cont">亲，暂无自提门店哦</text>
				</view>
			</view>
		</view>
	</view>
</template>


<script>
	export default {
		data() {
			return {
				/*数据*/
				listData: [],
				isLoading: true, // 是否正在加载中
				storeList: [], // 门店列表,
				longitude: '',
				latitude: '',
				selectedId: -1,
				is_select:0
			}
		},
		onLoad(options) {
      this.setGlobalColor()
			// 记录已选中的id
			this.selectedId = options.store_id;
			this.is_select = options.is_select ? options.is_select : 0;
			/*获取地址列表*/
			//this.getLocation();
			this.getData();
		},
		methods: {
			  /**
			   * 授权启用定位权限
			   */
			  onAuthorize() {
			    let self = this;
			    uni.openSetting({
			      success(res) {
			        if (res.authSetting["scope.userLocation"]) {
			          console.log('授权成功');
					  self.isAuthor = true;
			          setTimeout(() => {
			            // 获取用户坐标
			            self.getLocation((res) => {
			             
			            });
			          }, 1000);
			        }
			      }
			    })
			  },
			/**
			 * 获取用户坐标
			 */
			getLocation(callback) {
				let self = this;
				uni.getLocation({
					type: 'wgs84',
					success(res) {
						self.longitude = res.longitude;
						self.latitude = res.latitude;
						self.getData();
					},
					fail() {
						uni.showToast({
						    title: '获取定位失败，请点击右下角按钮打开定位权限',
						    duration: 2000
						});
						self.isAuthor=false;
					},
				})
			},

			/*获取数据*/
			getData() {
				let self = this;
				self.isLoading = true;
				self._get('store.store/lists', {
					longitude: self.longitude,
					latitude: self.latitude
				}, function(res) {
					self.isLoading = false;
					self.storeList = res.data.list;
				});
			},

			/**
			 * 选择门店
			 */
			onSelectedStore(e) {
				let self = this;
				self.selectedId = e;
				// 设置上级页面的门店id
				let pages = getCurrentPages();
				if (pages.length < 2) {
					return false;
				}
				// 触发全局的 选择门店 自定义事件,其他页面监听接收
				uni.$emit('selectStoreId',e)
				// 返回上级页面
				uni.navigateBack({
					delta: 1
				});
			},
			takePhone(e){
				uni.makePhoneCall({
				    phoneNumber: e 
				});
			},
			showAddress(lat,lng,addr){
				// uni.navigateTo({
				// 	url: '/pages/map/index/index?lat=' + lat + '&lng=' + lng
				// });
				uni.openLocation({
					latitude:parseFloat(lat),
					longitude:parseFloat(lng),
					name:addr,
					address:addr
				})
			}


		}
	}
</script>

<style>
	.address-list {
		padding-bottom: 90rpx;
	}

	.foot-btns {
		padding: 0;
	}

	.foot-btns .btn-red {
		width: 100%;
		height: 90rpx;
		line-height: 90rpx;
		border-radius: 0;
	}
	.select_store{
		display: inline-block; 
		padding: 5rpx 14rpx;
		word-spacing:2rpx;
		background-color: rgb(226, 35, 26);
		color:white;
		border-radius: 10rpx;
		position: absolute;
		right:40rpx;
	}
	.store_name{
		font-weight: bolder;
	}
</style>
