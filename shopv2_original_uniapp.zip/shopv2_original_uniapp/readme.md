初始化

## ext.json模板
```json
{
  "extAppid": "wxcf5a5b0465888aac",
  "extEnable": true,
  "directCommit": false,
  "ext": {
    "app_id":"10017",
    "app_url":"https://demo.shoprxr.com"
  }
}
```