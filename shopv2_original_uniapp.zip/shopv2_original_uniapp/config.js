import utils from "./common/utils"
let config = {
  url: {
    prod: 'https://demo.shoprxr.com',
    test: 'http://demo.shoprxr.com',
    dev: 'http://demo.shoprxr.com',
  },
  appId: {
    prod: 10017,
    test: 10001,
    dev: 10001,
  },
  msgPrefix: {
    prod: '[h5]',
    test: '[h5-test]',
    dev: '[h5-dev]',
  },
  receiver: {
    prod: ['王家聪', '郑炜华', '全建誉'],
    test: '全建誉',
    dev: '全建誉',
  },
  WxCpErrorReport: {
    prod: true,
    test: false,
    dev: false,
  },
  XDebug: {
    prod: false,
    test: false,
    dev: true,
  },
  /**
   * 环境定义
   */
  ENV: {
    PROD: 'prod',
    TEST: 'test',
    DEV: 'dev',
  },
  /**
   * 根据环境获取不同的配置
   * @param env
   * @param w7
   */
  getConfig(env, w7) {
    let h5_addr = '/h5'
    let app_id = this.appId[env]
    let WxCpErrorReport = this.WxCpErrorReport[env]
    let receiver = this.receiver[env]
    let msgPrefix = this.msgPrefix[env]
    let app_url = this.url[env]
    let XDebug = this.XDebug[env]
    // #ifdef H5
    if (process.env.NODE_ENV === 'production') {
      let url = utils.getHost()
      if (w7) {
        url = url + "/addons/miku_vkshop/web/"
        h5_addr = "/addons/miku_vkshop/web/" + h5_addr
      }
      const id = utils.getQueryVariable('app_id')
      if (url) { app_url = url }
      if (id) { app_id = id }
    }
    //#endif

    // #ifdef  MP-WEIXIN
    const extConfig = uni.getExtConfigSync ? uni.getExtConfigSync() : {}
    if (extConfig && extConfig.app_url && extConfig.app_id) {
      app_url = extConfig.app_url
      app_id = extConfig.app_id
    }
    if (utils.isArray(receiver)) {
      receiver = receiver.join('|')
    }
    //#endif
    return {
      /*服务器地址*/
      app_url,
      /*app_id*/
      app_id,
      //h5发布路径
      h5_addr,
      // 调试参数
      XDebug,
      // 是否开启企业微信错误通知
      WxCpErrorReport,
      // 通知人员
      receiver,
      // 消息体前缀
      msgPrefix,
    }
  },
}
// 是否开启微擎环境
let w7 = false
// 环境切换
// prod     test    dev
let env = config.ENV.PROD
if (process.env.NODE_ENV === 'development') {
  env = config.ENV.PROD
}
export default config.getConfig(env, w7)

