import Vue from 'vue'
import App from './App'
import store from './store'
import './common/iconfont.css'
import utils from './common/utils.js'
import config from './config.js'
import { gotopage } from '@/common/gotopage.js'
import StorageExpired from "@/common/storage"

import uView from '@/uni_modules/uview-ui'
Vue.use(uView)

Vue.prototype.$ls = new StorageExpired()

Vue.config.productionTip = false

App.mpType = 'app'

Vue.prototype.config = config

const app = new Vue({
    store,
    ...App
})
app.$mount()

Vue.prototype.websiteUrl = config.app_url;
Vue.prototype.app_id = config.app_id;
//h5发布路径
Vue.prototype.h5_addr = config.h5_addr;
/*页面跳转*/
Vue.prototype.gotoPage = gotopage;

//#ifdef H5
app.$router.afterEach((to, from) => {
    const u = navigator.userAgent.toLowerCase()
    if (u.indexOf("like mac os x") < 0 || u.match(/MicroMessenger/i) != 'micromessenger') return
    if (to.path !== global.location.pathname) {
        location.assign(config.h5_addr + to.fullPath);
    }
})
//#endif

// 全局错误捕获
Vue.config.errorHandler = (err, vm, info) => {
    console.log('进入全局异常捕获')
    console.error(err)
    console.error(vm)
    console.error(info)
    let msg = []
    msg.push(config.msgPrefix + '全局异常捕获')
    msg.push(`错误信息:${err.toString()}<br/>`)
    if (vm && vm.route) {
        msg.push(`页面:${vm.route}`)
    }
    if (info) {
        msg.push(`类型:${info}`)
    }
    if (config.WxCpErrorReport && process.env.NODE_ENV === 'production') {
        utils.sendWxCpMsg(config.receiver, msg)
    }
}

//是否是ios
Vue.prototype.ios = function () {
    const u = navigator.userAgent.toLowerCase();
    if (u.indexOf("like mac os x") < 0 || u.match(/MicroMessenger/i) != 'micromessenger') {
        return false;
    }
    return true;
};

//get请求
Vue.prototype._get = function (path, data, success, fail, complete) {
    data = data || {};
    data.token = uni.getStorageSync('token') || '';
    data.app_id = this.getAppId();
    if (config.XDebug) data.XDEBUG_SESSION_START = 'PHPSTORM'
    uni.request({
        url: this.websiteUrl + '/index.php/api/' + path,
        data: data,
        dataType: 'json',
        method: 'GET',
        success: (res) => {
            if (res.statusCode !== 200 || typeof res.data !== 'object') {
                return false;
            }
            if (Number(res.data.code) === -2) {
                // 禁止使用本商城
                uni.redirectTo({
                    url:'/pages/error/error?text='+res.data.msg
                })
                return false
            } else if (res.data.code === -1) {
                // 登录态失效, 重新登录
                console.log('登录态失效, 重新登录');
                this.doLogin();
            } else if (res.data.code === 0) {
                this.showError(res.data.msg, function () {
                    fail && fail(res);
                });
                return false;
            } else {
                success && success(res.data);
            }
        },
        fail: (res) => {
            fail && fail(res);
        },
        complete: (res) => {
            uni.hideLoading();
            complete && complete(res);
        },
    });
};

//get请求
Vue.prototype._post = function (path, data, success, fail, complete) {
	data = data || {};
    data.token = uni.getStorageSync('token') || '';
    data.app_id = this.getAppId();
    if (config.XDebug) data.XDEBUG_SESSION_START = 'PHPSTORM'
    uni.request({
        url: this.websiteUrl + '/index.php/api/' + path,
        data: data,
        dataType: 'json',
        method: 'POST',
        header: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        success: (res) => {
            if (res.statusCode !== 200 || typeof res.data !== 'object') {
                return false;
            }
            if (Number(res.data.code) === -2) {
                // 禁止使用本商城
                uni.redirectTo({
                    url:'/pages/error/error?text='+res.data.msg
                })
            } else if (res.data.code === -1) {
                // 登录态失效, 重新登录
                console.log('登录态失效, 重新登录');
                this.doLogin();
            } else if (res.data.code === 0) {
                this.showError(res.data.msg, function () {
                    fail && fail(res);
                });
                return false;
            } else {
                success && success(res.data);
            }
        },
        fail: (res) => {
            fail && fail(res);
        },
        complete: (res) => {
            uni.hideLoading();
            complete && complete(res);
        },
    });
};

Vue.prototype.doLogin = function () {
    let pages = getCurrentPages();
    if (pages.length) {
        let currentPage = pages[pages.length - 1];
        if ("pages/login/login" != currentPage.route) {
            uni.setStorageSync("currentPage", currentPage.route);
            uni.setStorageSync("currentPageOptions", currentPage.options);
        }
    }
    //公众号 授权登录
    // #ifdef  H5
    let appinfo = uni.getStorageSync('appinfo');
    if (this.isWeixn() && appinfo && appinfo.is_open_wx_mp_login) {
        //后台配置完整
        console.log(appinfo);
        let mpapp_id = '';
        let mpapp_secret = '';
        if (appinfo.setting) {
            mpapp_id = appinfo.setting.mpapp_id ? appinfo.setting.mpapp_id : '';
            mpapp_secret = appinfo.setting.mpapp_id ? appinfo.setting.mpapp_secret : '';
        }
        if (mpapp_id && mpapp_secret) {
            window.location.href = this.websiteUrl + '/index.php/api/user.usermp/login?app_id=' + this.getAppId() + '&referee_id=' + uni.getStorageSync('referee_id');
            return true;
        }
    }
    //有短信跳短信
    if (appinfo.is_open_sms) {
        uni.navigateTo({
            url: "/pages/login/weblogin"
        });
    } else {
        uni.navigateTo({
            url: "/user/pages/user/login"
        });
    }
    // #endif
    // 非公众号,跳转授权页面,下面跳小程序授权
    // #ifndef  H5
    uni.navigateTo({
        url: "/pages/login/login"
    });
    // #endif
};


/**
 * 显示失败提示框
 */
Vue.prototype.showError = function (msg, callback) {
    uni.showModal({
        title: '友情提示',
        content: msg,
        showCancel: false,
        success: function (res) {
            callback && callback();
        }
    });
};

/**
 * 显示失败提示框
 */
Vue.prototype.showSuccess = function (msg, callback) {
    uni.showModal({
        title: '友情提示',
        content: msg,
        showCancel: false,
        success: function (res) {
            callback && callback();
        }
    });
};

/**
 * 获取应用ID
 */
Vue.prototype.getAppId = function () {
    return this.app_id || 10001;
};

Vue.prototype.compareVersion = function (v1, v2) {
    v1 = v1.split('.')
    v2 = v2.split('.')
    const len = Math.max(v1.length, v2.length)

    while (v1.length < len) {
        v1.push('0')
    }
    while (v2.length < len) {
        v2.push('0')
    }

    for (let i = 0; i < len; i++) {
        const num1 = parseInt(v1[i])
        const num2 = parseInt(v2[i])

        if (num1 > num2) {
            return 1
        } else if (num1 < num2) {
            return -1
        }
    }

    return 0
};

/**
 * 生成转发的url参数
 */
Vue.prototype.getShareUrlParams = function (params) {
    let self = this;
    return utils.urlEncode(Object.assign({
        referee_id: self.getUserId()
    }, params));
};

/**
 * 当前用户id
 */
Vue.prototype.getUserId = function () {
    return uni.getStorageSync('user_id');
};

//#ifdef H5
var jweixin = require('jweixin-module');

Vue.prototype.configWx = function (signPackage, shareParams, params) {
    if (!signPackage || signPackage === '') {
        return;
    }
    let self = this;
    jweixin.config(JSON.parse(signPackage));

    let url_params = self.getShareUrlParams(params);

    jweixin.ready(function (res) {
        jweixin.updateAppMessageShareData({
            title: shareParams.title,
            desc: shareParams.desc,
            link: self.websiteUrl + self.h5_addr + shareParams.link + '?' + url_params,
            imgUrl: shareParams.imgUrl,
            success: function () {

            }
        });
        jweixin.updateTimelineShareData({
            title: shareParams.title,
            desc: shareParams.desc,
            link: self.websiteUrl + self.h5_addr + shareParams.link + '?' + url_params,
            imgUrl: shareParams.imgUrl,
            success: function () {

            }
        });
    });
};
//#endif

/**
 * 获取当前平台
 */
Vue.prototype.getPlatform = function (params) {
    let platform = 'wx';
    // #ifdef  H5
    if (this.isWeixn()) {
        platform = 'mp';
    } else {
        platform = 'h5';
    }
    // #endif
    return platform;
};

/**
 * 订阅通知,目前仅小程序
 */
Vue.prototype.subMessage = function (temlIds, callback) {
    let self = this;
    // #ifdef  MP-WEIXIN
    //小程序订阅消息
    const version = wx.getSystemInfoSync().SDKVersion;
    if (temlIds && temlIds.length != 0 && self.compareVersion(version, '2.8.2') >= 0) {
        wx.requestSubscribeMessage({
            tmplIds: temlIds,
            success(res) {},
            fail(res) {},
            complete(res) {
                callback();
            },
        });
    } else {
        callback();
    }
    // #endif
    // #ifndef MP-WEIXIN
    callback();
    // #endif
};

Vue.prototype.isWeixn = function () {
    var ua = navigator.userAgent.toLowerCase();
    if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
    } else {
        return false;
    }
};

/**
 * 根据后台设置,标题文本颜色
 */
Vue.prototype.setGlobalColor = function () {
    let isDefault = store.getters.isDefault
    if (isDefault) {
        let titleBackgroundColor = store.getters.titleBackgroundColor || '#EE1414'
        let titleTextColor = store.getters.titleTextColor || '#ffffff'
        utils.setTitleStyle(titleTextColor, titleBackgroundColor)
    }
}

/**
 * 设置元素前景色,返回style字符串
 * mainColor = true 设置前景色 主色调
 */
Vue.prototype.setColor = function (isMainColor = false) {
    let isDefault = store.getters.isDefault
    let res = {};
    if (isDefault) {
        // 主色调
        const mainColor = utils.getMainColor()
        // 文字颜色, 根据后台设置,如果开启反色,获取主色调的反色,未开启就是获取标题字体颜色
        const textColor = utils.getTextColor()
        if (textColor) {
            res.color = textColor
        }
        if (isMainColor) {
            if (mainColor) {
                res.color = mainColor
            }
        }
    }
    return res;
}

/**
 * 设置元素前景色,返回style字符串
 */
Vue.prototype.setBackgroundColor = function (border = true) {
    let isDefault = store.getters.isDefault
    let res = {};
    if (isDefault) {
        const mainColor = utils.getMainColor()
        if (mainColor) {
            res.backgroundColor = mainColor
            if (border) {
                res.border = `1px solid ${mainColor}`
            }
        }
    }
    return res;
}

/**
 * 获取元素背景色,返回颜色代码
 */
Vue.prototype.getMainColor = function () {
    return utils.getMainColor() || ''
}

/**
 * 获取元素前景色,返回颜色代码
 */
Vue.prototype.getTextColor = function () {
    return utils.getTextColor() || ''
}
