<template>
	<view>
		<view>
		    <view style="width:750rpx;height:800rpx;">
				<view style="text-align: center;padding: 40rpx;">
					<view>{{supply_name}}</view>
				</view>
		        <image :src="qrcode" class="qrcode" mode=""></image>
				<view style="height:40rpx;"></view>
				<view style="margin:auto;text-align: center;">扫描或长按识别，成为会员</view>
			</view>
			
		    <view style="height:40rpx;"></view>

		    <view class="fix-painter-share">
		        <button @click="saveImage" class="fr" style="width:100%;">保存图片</button>
		    </view>
		    <view style="height:40rpx;"></view>
		</view>
	</view>
</template>

<script>
	import utils from '@/common/utils.js';
	export default {
		data() {
			return {
				supply_id:0,
				qrcode:'',
				supply_name:','
			}
		},
		onLoad(e) {
			/*门店id*/
			let scene = utils.getSceneData(e);
			if(e.supply_id||scene.supply_id){
				this.supply_id = e.supply_id ? e.supply_id : scene.supply_id;
			}
			
		},
		mounted() {
      this.setGlobalColor()
			/*获取门店码*/
			this.getCardQrcode();
		},
		methods: {
			/*获取门店详情*/
			getCardQrcode(){
				let self = this;
				let supply_id = self.supply_id;
				
				let source = 'wx';
				//#ifdef H5
				source = 'mp';
				//#endif
				uni.showLoading({
					title: '加载中'
				});
				self._get(
					'plus.supply.supply/qrCode',
					{
						supply_id: supply_id,
						source:source,
						url: self.url,
					},
					function(res) {
						self.qrcode = res.data.qrcode;
						self.supply_name = res.data.supply_name;
						self.loadding = false;
						uni.hideLoading();
					}
				);
			},
			
			/* 保存 */
			saveImage(){
				
				let self = this;
				uni.showLoading({
					title: '加载中'
				});
				// 下载海报图片
				uni.downloadFile({
					url: self.qrcode,
					success(res) {
						uni.hideLoading();
						// 图片保存到本地
						uni.saveImageToPhotosAlbum({
							filePath: res.tempFilePath,
							success(data) {
								uni.showToast({
									title: '保存成功',
									icon: 'success',
									duration: 2000
								});
							},
							fail(err) {
								if (err.errMsg === 'saveImageToPhotosAlbum:fail auth deny') {
									uni.showToast({
										title: '请允许访问相册后重试',
										icon: 'none',
										duration: 1000
									});
									setTimeout(() => {
										uni.openSetting();
									}, 1000);
								}
							},
							complete(res) {
								console.log('complete');
							}
						});
					}
				});
				
			}
		}
	}
</script>

<style>
	page {
		background: #efeff5;
	}
	.fix-painter-share {
	    width: 100%;
	    height: 90rpx;
	    line-height: 90rpx;
	    bottom: 0rpx;
	    color: white;
	    background: white;
	    border-radius: 0rpx;
	}
	
	.fix-painter-share button {
	    width: 100%;
	    height: 90rpx;
	    line-height: 90rpx;
	    color: white;
	    background: #1aad19;
	    border-radius: 0rpx;
	}

	.fix-painter-share {
		width: 90%;
		padding: 0rpx 5%;
		background: none;
	}

	.fix-painter-share button {
		padding: 0rpx;
		width: 47.5%;
		font-size: 32rpx;
		border-radius: 10rpx;
	}

	.fix-painter-share button.fl {
		color: #000000;
		background: none;
		border: 1rpx solid #d8d8d8;
	}
	.qrcode{
		width: 400rpx;
		height: 400rpx;
		margin: auto;
	}
	
</style>
