<template>
  <view>
    <!-- #ifdef MP -->
    <view class="supply-bar">
      <view>
        <view class="left">
          <image class="supply_logo" :src="supply.image_url" mode="aspectFill"></image>
          <view class="">
            <view class="name">{{ supply.name }}</view>
            <view class="desc">简介:{{ supply.introduce }}</view>
          </view>
          <view class="btn-supply" @click="showSupplyQrcode">
            <i class="icon iconfont icon-erweima"></i>
            <view class="text-desc">二维码</view>
          </view>
          <button class="btn-supply" hover-class="none" open-type="share">
            <i class="icon iconfont icon-share"></i>
            <view class="text-desc">分享</view>
          </button>
        </view>
      </view>
    </view>
    <!-- #endif -->

    <scroll-view scroll-y="true" class="scroll-Y" :style="'height:' + scrollviewHigh + 'px;'" lower-threshold="50" @scrolltolower="scrolltolowerFunc">
      <!-- banner -->
      <view class="diy-banner-box">
        <swiper class="swiper" :indicator-dots="indicatorDots" :indicator-active-color="indicatorActiveColor" :autoplay="autoplay" :interval="interval" :duration="duration">
          <swiper-item v-for="(item,index) in bannerData" :key="index">
            <image :src="item.image_url" @click="gotoList(item.product_id)"></image>
          </swiper-item>
        </swiper>
      </view>
      <!-- 店家 -->
      <!-- #ifdef H5 -->
      <view class="supply-item">
        <view class="cmt-user">
          <view class="left">
            <image class="supply" :src="supply.image_url" mode="aspectFill"></image>
            <view class="">
              <view class="name">{{ supply.name }}</view>
              <view class="supply-desc">简介:{{ supply.introduce }}</view>
            </view>

          </view>
        </view>
      </view>
      <!-- #endif -->

      <!-- 视频 -->
      <view class="video-style" v-if="supply.video">
        <video :src="supply.video" :poster="supply.poster" objectFit="contain"></video>
      </view>
      <!-- #ifdef MP -->
      <view class="zhanwei"></view>
      <!-- #endif -->
      <!-- 搜索框 -->
      <view class="search-box">
        <form @submit="formSubmit" @reset="formReset">
          <view class="search-content">
            <view class="search-input">
              <input name="keword" class="search-text" placeholder="店内搜索产品"></input>
            </view>
            <view class="search" form-type="submit">

              <button form-type="submit">
                <text class="icon iconfont icon-sousuo"></text>
              </button>
            </view>

          </view>
        </form>
      </view>

      <!-- 广告位 -->
      <view class="ad_style" v-if="adinfo.supply_top">
        <image :src="adinfo.supply_top" mode="widthFix"></image>
      </view>
      <view class="prodcut-list-wrap">

        <view :class="topRefresh?'top-refresh open':'top-refresh'">
          <view class="circle" v-for="(circle,n) in 3" :key="n"></view>
        </view>
        <view class="list" v-if="product_column=='two_column'">
          <view class="item" v-for="(item, index) in listData" :key="index" @click="gotoList(item.product_id)">
            <view class="product-cover">
              <image :src="item.product_image" mode="aspectFill"></image>
            </view>
            <view class="product-info">
              <view class="product-title">
                {{ item.product_name }}
              </view>
              <view class="d-b-c mt20">
                <view class="already-sale">
                  <text>已售{{ item.product_sales }}件</text>
                </view>
                <view class="price" v-if="item.buy_auth.can_buy>0||item.buy_auth.no_price==0">
                  ¥
                  <text class="num">{{ item.product_sku.product_price }}</text>
                </view>
              </view>
            </view>
          </view>
        </view>
        <view class="list1" v-else-if="product_column=='one_column'">
          <view class="product-item-box1" v-for="(item, index) in listData" :key="index">
            <view class="product-cover" :style="'display: flex;align-items: center; background: url('+item.poster+');background-size: 100% 100%;'" v-if="item.video&&item.poster!=''">
              <video :src="item.video" style="width: 100%;height: 56.25%;"></video>
            </view>
            <view class="product-cover-video" v-else-if="item.video&&!item.poster">
              <video :src="item.video" style="width: 100%;height: 100%;"></video>
            </view>
            <view class="product-cover" v-else>
              <image @click="gotoList(item.product_id)" :src="item.product_image" mode="aspectFill"></image>
            </view>
            <view class="product-title1" @click="gotoList(item.product_id)">
              <view class="product-item-box6">
                <div>{{ item.product_name }}</div>
              </view>
              <view class="subtitle">
                <text v-if="item.subtitle">{{ item.subtitle }}</text>
              </view>
              <view class="product-item-box5">
                <text class="f331" style="font-size: 30rpx; color: red;">￥{{ item.product_price }}</text>
                <text class="f33" style="font-size: 25rpx;padding-left: 30rpx; text-decoration:line-through">￥{{ item.product_sku.line_price }}</text>
                <text class="f44" style="font-size: 25rpx;padding-left: 40rpx;">
                  已售{{ item.product_sales }}件
                </text>
              </view>
            </view>

          </view>
        </view>
        <view class="list1" v-else-if="product_column=='video_scale'">
          <view class="product-item-box1" v-for="(item, index) in listData" :key="index">
            <view class="product-cover" :style="'display: flex;align-items: center; background: url('+item.poster+');background-size: 100% 100%;'" v-if="item.video&&item.poster">
              <video :src="item.video" style="width: 100%;height: 56.25%;"></video>
            </view>
            <view class="product-cover-video" v-else-if="item.video&&!item.poster">
              <video :src="item.video" style="width: 100%;height: 100%;"></video>
            </view>
            <view class="product-cover-video" v-else>
              <image @click="gotoList(item.product_id)" :src="item.product_image" mode="aspectFill"></image>
            </view>
            <view class="product-title1" @click="gotoList(item.product_id)">
              <view class="product-item-box6">
                <div>{{ item.product_name }}</div>
              </view>
              <view class="subtitle">
                <text v-if="item.subtitle">{{ item.subtitle }}</text>
              </view>
              <view class="product-item-box5">
                <text class="f331" style="font-size: 30rpx; color: red;">￥{{ item.product_price }}</text>
                <text class="f33" style="font-size: 25rpx;padding-left: 30rpx; text-decoration:line-through">￥{{ item.product_sku.line_price }}</text>
                <text class="f44" style="font-size: 25rpx;padding-left: 40rpx;">
                  已售{{ item.product_sales }}件
                </text>
              </view>
            </view>

          </view>
        </view>
        <!-- 广告位 -->
        <view class="ad_style" v-if="adinfo.supply_bottom">
          <image :src="adinfo.supply_bottom" mode="widthFix"></image>
        </view>
        <!-- 没有记录 -->
        <view class="d-c-c p30" v-if="listData.length==0 && !loading">
          <text class="iconfont icon-wushuju"></text>
          <text class="cont">亲，暂无相关记录哦</text>
        </view>
        <uni-load-more v-else :loadingType="loadingType"></uni-load-more>

      </view>

    </scroll-view>

    <Tabbar></Tabbar>
  </view>
</template>

<script>
import utils from '@/common/utils.js';
import uniLoadMore from "@/components/uni-load-more.vue";
import Tabbar from "@/components/tabbar/tabbar.vue";

export default {
  components: {
    uniLoadMore,
    Tabbar
  },
  data() {
    return {
      /*手机高度*/
      phoneHeight: 0,
      /*可滚动视图区域高度*/
      scrollviewHigh: 0,
      /*顶部刷新*/
      topRefresh: false,
      /*底部加载*/
      loading: true,
      /*没有更多*/
      no_more: false,
      /*类别选中*/
      type_active: 0,
      /*价格选中*/
      price_top: false,
      /*商品列表*/
      listData: [],
      /*当前页面*/
      page: 1,
      category_id: 0,
      search: '',
      sortType: '',
      sortPrice: 0,
      list_rows: 10,
      last_page: 0,
      supply: {
        image_url: '',
        name: '',
        introduce: ''
      },
      supply_id: 0,
      bannerData: [],
      indicatorDots: true,
      autoplay: true,
      interval: 2000,
      duration: 500,
      indicatorActiveColor: '#ffffff',
      product_column: 'one_column',
      adinfo: {}
    };
  },
  computed: {

    /*加载中状态*/
    loadingType() {
      if (this.loading) {
        return 1;
      } else {
        if (this.listData.length != 0 && this.no_more) {
          return 2;
        } else {
          return 0;
        }
      }
    }
  },
  onLoad(e) {
    // 商家id
    let scene = utils.getSceneData(e);
    this.supply_id = e.supply_id ? e.supply_id : (scene.supply_id ? scene.supply_id : 0);
    let current_supply_id = uni.getStorageSync('currentSupplyId');
    if (!this.supply_id && current_supply_id) {
      this.supply_id = current_supply_id;
    }
  },
  mounted() {
    this.setGlobalColor()
    this.init();
    /*获取产品列表*/
    this.getSupply();
    if (this.supply_id) {
      this.getData();
      this.getBanner();
      this.getAdImg();
    }
  },
  onPullDownRefresh() {
    /*下拉到顶，页面值还原初始化*/
    this.restoreData();
    this.getData();

  },
  methods: {
    /*初始化*/
    init() {
      let _this = this;
      uni.getSystemInfo({
        success(res) {
          _this.phoneHeight = res.windowHeight;
          _this.scrollviewHigh = res.windowHeight;
          // 计算组件的高度
          // let view = uni.createSelectorQuery().select('.top-box');
          // view.boundingClientRect(data => {
          // 	console.log(_this.phoneHeight,data.height)
          // 	let h = _this.phoneHeight - data.height;
          // 	_this.scrollviewHigh = h;
          // }).exec();
        }
      });
    },
    /*还原初始化*/
    restoreData() {
      this.listData = [];
      this.search = '';
    },


    /*获取数据*/
    getData() {
      let self = this;
      let page = self.page;
      let list_rows = self.list_rows;
      let supply_id = self.supply_id;
      let search = self.search;
      self.loading = true;
      self._get('product.product/lists', {
        page: page || 1,
        supply_id: supply_id,
        search: search
      }, function (res) {
        self.loading = false;
        self.listData = self.listData.concat(res.data.list.data);
        self.last_page = res.data.list.last_page;
        if (res.data.list.last_page <= 1) {
          self.no_more = true;
        }
      });
    },
    /*获取供应商数据*/
    getSupply() {
      let self = this;
      let supply_id = self.supply_id;
      self._get('plus.supply.supply/detail', {
        supply_id: supply_id,
      }, function (res) {
        self.supply = res.data.supply;
        if (self.supply) {
          self.product_column = res.data.supply.product_show;
        }
        if (!self.supply_id) {
          self.supply_id = res.data.supply.supply_id;
          self.getBanner();
          self.getData();
          self.getAdImg();
        }


      });
    },
    // 获取banner数据
    getBanner() {
      let self = this;
      let supply_id = self.supply_id;
      self._get('plus.banner.banner/index', {
        supply_id: supply_id
      }, function (res) {
        self.bannerData = res.data.list.data;

      });
    },
    /*跳转产品*/
    gotoList(e) {
      if (e) {
        let url = 'main/pages/product/detail/detail?product_id=' + e
        this.gotoPage(url);
      }

    },
    /*可滚动视图区域到底触发*/
    scrolltolowerFunc() {

      let self = this;
      self.bottomRefresh = true;
      self.page++;
      self.loading = true;
      if (self.page > self.last_page) {
        self.loading = false;
        self.no_more = true;
        return;
      }
      self.getData();
    },
    /**
     * 设置分享内容
     */
    onShareAppMessage() {
      // 构建分享参数
      let title = this.supply.name;
      return {
        title: title,
        path: "/plus/pages/supply/detail/detail?supply_id=" + this.supply.supply_id
      };
    },
    // 信息提交
    formSubmit: function (e) {
      let self = this;
      self.listData = [];
      self.page = 1;
      self.no_more = false;
      self.loading = true;
      self.search = e.detail.value.keword;
      self.getData();
    },

    // 显示店铺二维码
    showSupplyQrcode() {

      let url = 'plus/pages/supply/qrcode/qrcode?supply_id=' + this.supply_id
      this.gotoPage(url);
    },
    /*
    * 获取广告图片
    */
    getAdImg() {
      let self = this;
      let supply_id = self.supply_id;
      self._get('plus.supply.supply/getAdImg', {
        supply_id: supply_id
      }, function (res) {
        self.adinfo = res.data.adinfo;
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.search-box {
  font-size: 28rpx;
  padding: 20rpx;
  background-color: #fff;
}

.search-box .search-content {
  position: relative;
  background-color: #f6f6f6;
  border-radius: 40rpx;
  display: block;
}

.search-input {
  display: block;
  height: 40px;
  width: 580rpx;
  padding: 0 10px 0 20px;
  background: #f4f4f4;
  color: #333;
  border-radius: 40rpx;
}

.search-text {
  display: flex;
  position: relative;
  width: 100%;
  height: 100%;
  line-height: 80rpx;
  // transform: translateY(-50%);
}

.search {
  position: absolute;
  top: 50%;
  right: 10rpx;
  transform: translateY(-50%);
  // font-size: 20px;
  z-index: 10;
  color: #89899a;
  width: 80rpx;
  line-height: 80rpx;
}

.search button {
  background: none;
}

.inner-tab {
  position: relative;
  height: 80rpx;
  display: flex;
  justify-content: space-around;
  align-items: center;
  border-bottom: 1px solid #dddddd;
  background: #ffffff;
  box-shadow: 0 8rpx 12rpx 0 rgba(0, 0, 0, .1);
  z-index: 9;
}

.inner-tab .item {
  flex: 1;
  font-size: 30rpx;
}

.inner-tab .item.active,
.inner-tab .item .arrow.active .iconfont {
  color: $dominant-color;
}

.inner-tab .item .box {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: row;
}

.inner-tab .item .arrows {
  margin-left: 10rpx;
  line-height: 0;
}

.inner-tab .item .iconfont {
  line-height: 24rpx;
  font-size: 24rpx;
}

.inner-tab .item .arrow,
.inner-tab .item .svg-icon {
  width: 20rpx;
  height: 20rpx;
}

.prodcut-list-wrap .list {
  padding: 20rpx;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  flex-wrap: wrap;
}

.prodcut-list-wrap .list .item {
  width: 350rpx;
  border-radius: 20rpx;
  margin-right: 10rpx;
  margin-bottom: 20rpx;
  padding-bottom: 20rpx;
  overflow: hidden;
  background: #ffffff;
  box-shadow: 0 0 8rpx rgba(0, 0, 0, .1);
  margin-bottom: 10rpx;
}

.prodcut-list-wrap .list .item:nth-child(2n+0) {
  margin-right: 0;
}

.prodcut-list-wrap .product-video-cover,
.prodcut-list-wrap .product-cover,
.prodcut-list-wrap .product-cover image {
  width: 350rpx;
  height: 350rpx;
}

.prodcut-list-wrap .product-info {
  padding: 0 24rpx;
}

.prodcut-list-wrap .product-title {
  height: 80rpx;
  margin-top: 20rpx;
  display: -webkit-box;
  overflow: hidden;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  font-size: 28rpx;
  line-height: 40rpx;
}

// .prodcut-list-wrap .already-sale {
// 	font-size: 30rpx;
// 	font-weight: bold;
// }
// .prodcut-list-wrap .already-sale>text{
// 	padding: 6rpx 10rpx;
// 	background-color: #f2f2f7;
// }

.prodcut-list-wrap .price {
  color: $dominant-color;
  font-size: 24rpx;
}

.prodcut-list-wrap .price .num {
  font-size: 30rpx;
  font-weight: bold;
}

.supply-item {
  padding: 10px 10px 0 10px;
  background: #fff;
  margin-top: 10rpx;
}

// .supply-item .cmt-user{
// 	background-color: #fff;
// }
.supply-item .left {
  display: flex;
}

.supply-item .supply {
  width: 140rpx;
  height: 140rpx;
  border-radius: 20rpx;
}

.supply-item .name {
  width: 480rpx;
  height: 36rpx;
  overflow: hidden;
  -webkit-line-clamp: 1;
  padding: 0 16rpx 16rpx 16rpx;
  font-size: 36rpx;
}

.supply-item .supply-desc {
  width: 480rpx;
  line-height: 28rpx;
  overflow: hidden;
  -webkit-line-clamp: 2;
  padding: 16rpx;
  font-size: 28rpx;
  color: #757575;;
}

.diy-banner-box, .diy-banner-box .swiper {
  width: 750rpx;
  height: 310rpx;
}

.diy-banner-box image {
  margin: 20rpx 20rpx 0;
  width: 710rpx;
  height: 290rpx;
  border-radius: 16rpx;
}

.supply-bar {
  padding: 10rpx;
  background: #fff;
  top: 0;
  border: none;
  width: 100%;
  min-width: 100%;
  box-shadow: 0px 4rpx 10rpx 0 rgba(0, 0, 0, 0.1);
  z-index: 99;
  overflow: hidden;
}

.supply-bar .left {
  display: flex;
}

.supply-bar .supply_logo {
  width: 80rpx;
  height: 80rpx;
  border-radius: 20rpx;
}

.supply-bar .name {
  width: 480rpx;
  height: 26rpx;
  overflow: hidden;
  -webkit-line-clamp: 1;
  padding: 0 10rpx 10rpx 10rpx;
  font-size: 26rpx;
}

.supply-bar .desc {
  width: 480rpx;
  line-height: 26rpx;
  overflow: hidden;
  -webkit-line-clamp: 2;
  padding: 10rpx;
  font-size: 24rpx;
  color: #757575;
}

.supply-bar .btn-supply {
  width: 80rpx;
  height: 80rpx;
  padding-left: 0rpx;
  padding-right: 0rpx;
  background-color: #fff;
  text-align: center;
}

.supply-bar .btn-supply .icon-image-style {
  width: 40rpx;
  height: 40rpx;
  margin: auto;
}

.supply-bar .btn-supply i {
  line-height: 1;
  font-size: 50rpx;
  color: #242424;
}

.supply-bar .btn-supply .text-desc {
  height: 20rpx;
  font-size: 20rpx;
  text-align: center;
}

.video-style {
  width: 750rpx;
  height: 430rpx;
  margin: 10rpx 0;
}

.video-style video {
  width: 100%;
}

.zhanwei {
  height: 30rpx;
}

.product-item-box1 {
  // margin-left: calc((750rpx - 94vw)/2);
  margin-bottom: 10rpx;
  width: 100%;
  border-radius: 20rpx;
  border: 1rpx solid #e1e1e1;
  background-color: #FFFFFF;
}

.product-item-box1 .product-cover {
  background-color: #FFFFFF;
  width: 750rpx;
  height: 750rpx;
}

.product-item-box1 .product-cover-video {
  background-color: #FFFFFF;
  width: 750rpx;
  height: 422rpx;
}

.product-item-box1 .product-cover-video image {
  width: 100%;
  height: 100%;
}

.product-item-box1 .product-cover image {
  width: 100%;
  height: 100%;
}

.product-item-box1 .product-cover video {
  width: 100%;
  height: 100%;
}

.product-title1 {
  margin-top: 20rpx;
  margin-left: 15rpx;
  font-size: 20px;
  padding-bottom: 20rpx;

}

.product-item-box6 {
  padding-left: 20rpx;
  padding-right: 20rpx;
  font-size: 40rpx;
}

.subtitle {
  color: #999999;
  padding: 0 20rpx;
  font-size: 30rpx;
}

.f44 {
  text-align: right;
  /* padding-bottom: 20rpx; */
}

.f33, .f44 {
  color: #999999;
}

.product-item-box5 {
  padding-left: 20rpx;
  text-align: left;
  padding-bottom: 20rpx;
}

.ad_style {
  width: 750rpx;
}

.ad_style image {
  width: 100%;
}
</style>
