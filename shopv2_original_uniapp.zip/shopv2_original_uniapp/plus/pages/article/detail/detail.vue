<template>
	<view class="article-detail" v-if="loadding">
		<view class="title fb">{{ article.article_title }}</view>
		<view class="info d-b-c f24">
			<view>
				<text class="red" v-if="article.category">{{ article.category.name}}</text>
				<text class="ml30">{{ article.create_time }}</text>
			</view>
		</view>
		<view class="article-content" v-html="article.article_content"></view>

		<!--分享-->
		<view class="share-box" :style="[bgcColor]">
			<button type="primary" @click="showShare"><text class="icon iconfont icon-share" :style="[textColor]"></text></button>
		</view>

		<!--底部弹窗-->
		<share :isbottmpanel="isbottmpanel" :product_id="article_id" @close="closeBottmpanel"></share>
	</view>
</template>

<script>
	import share from './popup/share.vue'
	import utils from '@/common/utils.js';
	export default {
		components: {
			share
		},
		data() {
			return {
				isbottmpanel: false,
				url: null,
				/*是否加载完成*/
				loadding: false,
				indicatorDots: true,
				autoplay: true,
				interval: 2000,
				duration: 500,
				/*文章id*/
				article_id: 0,
				/*文章详情*/
				article: {
					image: {}
				},
				from_user_id:'',
			};
		},
		onShow() {
			this.joinShare();
		},
		onLoad(e) {
			/*分类id*/
			this.article_id = e.article_id;
			this.from_user_id = e.from_user_id;
			//#ifdef H5
			this.url = window.location.href;
			//#endif
		},
    computed: {
      textColor() {
        return this.setColor()
      },
      bgcColor() {
        return this.setBackgroundColor()
      },
    },
		mounted() {
			/*获取产品详情*/
			this.getData();
      this.setGlobalColor()
		},
		methods: {
			// 用户参与分享
      joinShare() {
        if (this.from_user_id == 0) {
          return false;
        }
        let self = this;
        let params = {
          article_id: self.article_id,
          from_user_id: self.from_user_id,
          to_user_id: uni.getStorageSync('user_id'),
        };
        this._get('plus.sharePolite.SharePolite/getIntegral', params, function (res) {})
      },
			//关闭分享
			closeBottmpanel(data) {
				this.isbottmpanel = false;
				if (data.type == 2) {
					this.poster_img = data.poster_img;
					this.isCreatedImg = true;
				}
			},
			showShare() {
				this.isbottmpanel = true;
			},
			/*获取文章详情*/
			getData() {
				let self = this;
				uni.showLoading({
					title: '加载中'
				});
				this.loading = true;
				let article_id = self.article_id;
				this._get(
					'plus.article.article/detail', {
						article_id: article_id,
						url: self.url,
					},
					function(res) {
						/*详情内容格式化*/
						res.data.detail.article_content = utils.format_content(res.data.detail.article_content);

						self.article = res.data.detail;
						self.loadding = true;
						uni.hideLoading();

						// 配置微信分享参数
						if (self.url != '') {
							if (!uni.getStorageSync('user_id')) {
								self.doLogin();
							}

							let params = {
								article_id: self.article_id,
								from_user_id: uni.getStorageSync('user_id'),
							};
							self.configWx(res.data.share.signPackage, res.data.share.shareParams, params);
						}
					}

				);
			}
		}
	};
</script>

<style scoped>
	.share-box {
		position: fixed;
		padding-right: 10rpx;
		width: 80rpx;
		height: 80rpx;
		right: 0;
		bottom: 180rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		border-radius: 16rpx 0 0 16rpx;
		background: rgba(0, 0, 0, 0.8);
	}

	.share-box button {
		padding: 0;
		background: 0;
		line-height: 60rpx;
	}

	.share-box .iconfont {
		margin-bottom: 10rpx;
		font-size: 50rpx;
		color: #ffffff;
	}

	.article-detail {
		padding: 30rpx;
		background: #ffffff;
	}

	.article-detail .title {
		font-size: 44rpx;
	}

	.article-detail .info {
		padding: 40rpx 0;
		color: #999999;
	}

	.article-detail .article-content {
		width: 100%;
		box-sizing: border-box;
		line-height: 60rpx;
		font-size: 34rpx;
		overflow: hidden;
	}

	.article-detail .article-content image,
	.article-detail .article-content img {
		display: block;
		max-width: 100%;
	}
</style>
