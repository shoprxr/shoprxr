const globalStyle = {
    state: {
        // #2b9939  #EE1414
        titleBackgroundColor: '#EE1414',
        titleTextColor: '#ffffff',
        isDefault: false,
        isReverseColor: false,
        reverseColor: '',
    },
    mutations: {
        SET_TITLE_BACKGROUND_COLOR: (state, type) => {
            state.titleBackgroundColor = type
        },
        SET_IS_DEFAULT: (state, type) => {
            state.isDefault = type
        },
        SET_IS_REVERSE_COLOR: (state, type) => {
            state.isReverseColor = type
        },
        SET_REVERSE_COLOR: (state, type) => {
            state.reverseColor = type
        },
        SET_TITLE_TEXT_COLOR: (state, type) => {
            let colors = '#000000';
            if (type === 'white') {
                //字母要小写
                colors = '#ffffff'
            }
            state.titleTextColor = colors
        },
    },
    actions: {
        setTitleBackgroundColor ({ commit }, type) {
            commit('SET_TITLE_BACKGROUND_COLOR', type)
        },
        setTitleTextColor ({ commit }, type) {
            commit('SET_TITLE_TEXT_COLOR', type)
        },
        setIsDefault ({ commit }, type) {
            commit('SET_IS_DEFAULT', type)
        },
        setIsReverseColor ({ commit }, type) {
            commit('SET_IS_REVERSE_COLOR', type)
        },
        setReverseColor ({ commit }, type) {
            commit('SET_REVERSE_COLOR', type)
        },
    }
}

export default globalStyle
