export default {
    props: {
        bgColor: {
            type: String,
            default: uni.$u.props.statusBar.bgColor
        }
    }
}
