<template>
	<view class="diy-blank" :style="{height: itemData.style.height +'px', background:itemData.style.background }">
	</view>
</template>

<script>
	export default {
		data() {
			return {};
		},
		props: ['itemData'],
		methods: {}
	};
</script>

<style>
	
</style>
