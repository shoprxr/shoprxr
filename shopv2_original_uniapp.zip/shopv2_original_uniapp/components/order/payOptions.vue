<template>
  <!--支付方式-->
  <view class="buy-checkout" v-if="payTypeList && payTypeList.length > 0">
    <view :class="pay_type === payType.value ? 'item active' : 'item'" v-for="payType in payTypeList" :key="payType.value" @click="payTypeFunc(payType.value)">
      <view class="d-s-c">
        <view class="icon-box d-c-c mr10"><span :class="'icon iconfont ' + payType.icon" :style="'color: ' + payType.icon_color"></span></view>
        <text class="key">{{ payType.name }}支付：</text>
      </view>
      <view class="icon-box d-c-c"><span class="icon iconfont icon-xuanze"></span></view>
    </view>
  </view>
</template>

<script>
export default {
  name: "payOptions",
  data() {
    return {
      pay_type: 20
    }
  },
  props: {
    payTypeList: {
      type: Array,
      default: [
        {
          'name': '微信',
          'value': 20,
          'en_name': 'wechat',
          'icon': 'icon-weixin',
          'icon_color': '#04BE01',
        }
      ]
    },
    checkedPayType: {
      type: Number,
      default: 30
    }
  },
  watch: {
    checkedPayType(newVal, oldVal){
      if (newVal !== oldVal){
        this.pay_type = newVal
      }
    }
  },
  mounted(){
    this.payTypeFunc(this.checkedPayType)
  },
  methods: {
    /**
     * 选择支付方式触发
     * @param type
     */
    payTypeFunc(type){
      this.pay_type = type
      this.$emit('click', this.pay_type);
    },

  }

}
</script>

<style scoped></style>
