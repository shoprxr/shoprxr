<template>
	<view>
		<view :class="isIphoneX?'tabbarheightPhone':'tabbarheight'"></view>
		<view :class="isIphoneX?'tabbar isIphoneX':'tabbar'">
			<view class="item" v-for="(item, index) in tabbarData.data" :key="index" :style="'width:'+item_width+';'"
				@click="gotoDetail(item,index)">
				<image v-if="Number(item.icon_type) === 20" :src="curIndex === index ? item.selectImgUrl : item.imgUrl"
					mode="widthFix"></image>
				<span v-else :class="item.icon" :style="[icon(curIndex, index)]"></span>
				<text :class="curIndex === index?'gray3 active':'gray3'"
					:style="[text(curIndex, index)]">{{item.text}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	import utils from "@/common/utils";
	export default {
		data() {
			return {
				curIndex: 0,
				isIphoneX: 0,
				tabbarData: {
					style: {
						"background": "#ffffff",
						"rowsNum": "4",
					},
					data: [{
            icon_type: 10,
            icon: 'icon iconfont icon-Homehomepagemenu',
            color: '#E2231A',
            imgUrl: "http://imgh5.y01.cn/20210606232151557894522.png",
            selectImgUrl: "http://imgh5.y01.cn/20210606232200ed0035032.png",
            imgName: "icon-1.png",
            linkUrl: "pages/index/index",
            text: "首页",
            index: 0,
          },
            {
              icon_type: 10,
              icon: 'icon iconfont icon-shaixuan',
              color: '#E2231A',
              imgUrl: "http://imgh5.y01.cn/20210606232153b10536389.png",
              selectImgUrl: "http://imgh5.y01.cn/2021060623215814dc46504.png",
              imgName: "icon-2.jpg",
              linkUrl: "main/pages/product/category",
              text: "分类",
              index: 1,
            },
            {
              icon_type: 10,
              icon: 'icon iconfont icon-gouwuche',
              color: '#E2231A',
              imgUrl: "http://imgh5.y01.cn/202106062321494978c1576.png",
              selectImgUrl: "http://imgh5.y01.cn/20210606232156e95a89918.png",
              imgName: "icon-3.jpg",
              linkUrl: "pages/cart/cart",
              text: "购物车",
              index: 2,
            },
            {
              icon_type: 10,
              icon: 'icon iconfont icon-tuandui',
              color: '#E2231A',
              imgUrl: "http://imgh5.y01.cn/20210606232151970aa8749.png",
              selectImgUrl: "http://imgh5.y01.cn/202106062321585af9c0280.png",
              imgName: "icon-4.jpg",
              linkUrl: "pages/user/index/index",
              text: "我的",
              index: 3,
            },
          ],
				},
				item_width: '25%',
			}
		},
		created() {
			//console.log('created')
			var pages = getCurrentPages();
			var currentpage = pages[pages.length - 1];
			let self = this;
			let count = 0;
			let tabbar = uni.getStorageSync('tabbar');
			if (tabbar) {
				self.tabbarData = tabbar;
			}
			self.tabbarData.data.forEach(function(item, index) {
				let linkUrl = item.linkUrl;
				if (item.linkUrl.indexOf('?') !== false) {
					let linkUrl_arr = item.linkUrl.split('?');
					linkUrl = linkUrl_arr[0];
				}
				if (currentpage.route == linkUrl) {
					count = 1;
					self.curIndex = index;
					uni.setStorageSync('curIndex', index);
				}
			});
			if (count == 0) {
				uni.setStorageSync('curIndex', 0);
			}
			this.curIndex = uni.getStorageSync('curIndex');
			this.item_width = 100 / Math.abs(this.tabbarData.style.rowsNum) + '%';

			if (uni.getStorageSync('isIphoneX')) {
				this.isIphoneX = uni.getStorageSync('isIphoneX');
				console.log(this.isIphoneX);
			}

		},
		computed: {
			icon() {
				return (curIndex, index) => {
					let color = ''
					if (curIndex === index) {
						color = utils.getMainColor() || '#c70d0d'
					}
					return {
						color
					}
				}
			},
			text() {
				return (curIndex, index) => {
					let color = ''
					if (curIndex === index) {
						color = this.$store.getters.titleBackgroundColor || '#C82829'
					}
					return {
						color
					}
				}
			},
		},
		methods: {
			gotoDetail(e, key) {
				this.curIndex = key;
				let timestamp = new Date().getTime();
				uni.setStorageSync('curIndex', this.curIndex);
				let card_id = uni.getStorageSync('card_id');
				console.log("名片id:" + card_id);
				if (e.appid != undefined && e.appid != '') {
					uni.navigateToMiniProgram({
						// #ifdef MP
						appId: e.appid,
						path: e.linkUrl != undefined ? e.linkUrl : '',
						// #endif
					})
				} else {

					let url = e.linkUrl;

					if (card_id && e.linkUrl == 'card/pages/card/index') {
						let params = this.getShareUrlParams({
							card_id: card_id
						});
						console.log(params);
						url = url + "?" + params;
						console.log(url);
					}
					if (e.linkUrl.indexOf('?') !== -1) {
						url = url + "&t=" + timestamp;
					} else {
						url = url + "?t=" + timestamp;
					}
					console.log("当前路径:" + e.linkUrl);

					uni.reLaunch({
						url: '/' + url
					});
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '../../card/statics/5.css';

	.tabbarheightPhone {
		height: 130rpx;
	}

	.tabbarheight {
		height: 100rpx;
	}

	.tabbar {
		box-sizing: border-box;
		border-top: 1rpx solid #DDDDDD;
		position: fixed;
		background: #FFFFFF;
		display: flex;
		justify-content: flex-start;
		flex-wrap: wrap;
		left: 0;
		width: 100%;
		z-index: 998;
		bottom: 0;
	}

	.tabbar .item {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		margin-top: 10rpx;
		height: 100rpx;
	}

	/* 原来菜单图标是图片 */
	.tabbar .item image {
		position: relative;
		display: inline-block;
		margin-top: 5px;
		width: 48rpx;
		height: 48rpx;
	}

	/* 改为了现在的图标,方便控制颜色 */
	.tabbar .item .icon.iconfont {
		position: relative;
		display: inline-block;
		margin-top: -10px;
		width: 50rpx;
		height: 66rpx;
		font-size: 50rpx;
	}

	.tabbar .item text {
		position: relative;
		text-align: center;
		line-height: 1.8;
		font-size: 24rpx;

	}

	.active {
		color: #C82829;
	}

	.isIphoneX {
		padding-bottom: 30rpx;
	}
</style>
