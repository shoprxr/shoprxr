<template>
	<view class="wrap" v-if="!loading">
		<!--tab-->
		<view class="top-tabbar">
			<block v-if="hasType(10)">
				<view :class="tab_type == 0 ? 'tab-item active' : 'tab-item'" :style="[active(tab_type, 0)]" @click="tabFunc(0)">快递配送</view>
			</block>
			<block v-if="hasType(20)">
				<view :class="tab_type == 1 ? 'tab-item active' : 'tab-item'" :style="[active(tab_type, 1)]" @click="tabFunc(1)">上门自提</view>
			</block>
			<block v-if="hasType(40)">
				<view :class="tab_type == 2 ? 'tab-item active' : 'tab-item'" :style="[active(tab_type, 2)]" @click="tabFunc(2)">虚拟云仓</view>
			</block>
			<block v-if="hasType(30)">
				<view :class="tab_type == 3 ? 'tab-item active' : 'tab-item'" :style="[active(tab_type, 3)]" @click="tabFunc(3)">无需物流</view>
			</block>
		</view>

		<MyInfo v-if="tab_type == 0" :Address="Address" :exist_address="exist_address"></MyInfo>

		<StoreInfo v-if="tab_type == 1" ref="getShopinfoData" :extract_store="extract_store" :last_extract="last_extract"></StoreInfo>
		<Storage v-if="tab_type == 2" :tab_type = "tab_type"></Storage>
		<Storage v-if="tab_type == 3" :tab_type = "tab_type"></Storage>

		<!--购买的产品-->
		<view class="vender">
			<view class="confirm-tips red" >
				{{settings && settings.confirm_tips ? settings.confirm_tips : ''}}
			</view>
			<view class="group-hd">
				<view class="left"><text class="min-name">商品</text></view>
			</view>
			<view class="list">
				<view class="item" v-for="(item, index) in ProductData" :key="index">
					<view class="cover">
						<image :src="item.product_image" mode="aspectFit" style="width: 100px;"></image>
					</view>
					<view v-if="item.nobuy==true">
						<view class="info text-disabled">
							<view class="title" style="white-space: normal;">{{ item.product_name }}</view>
							<view class="describe">{{ item.product_sku.product_attr }}</view>
							<view class="level-box count_choose">
								<view class="price" :class="{'text-l-t':item.is_user_grade==true}">
									¥
									<text class="num">{{ item.product_price }}</text>
								</view>
								<view class="num-wrap">
									<view class="f22">×{{ item.total_num }}</view>
								</view>
							</view>
							<view class="nobuy" v-if="item.nobuy==true">
								{{item.nobuytext}}
							</view>
							<view class="mt10 tr f28" v-if="item.is_user_grade==true">
								<text class="red">会员折扣价：</text>
								<text class="red">{{item.grade_product_price}}</text>
							</view>
						</view>
					</view>
					<view v-else>
						<view class="info">
							<view class="title" style="white-space: normal;">{{ item.product_name }}</view>
							<view class="describe">{{ item.product_sku.product_attr }}</view>
							<view class="level-box count_choose">
								<view class="price" :class="{'text-l-t':item.is_user_grade==true}">
									¥
									<text class="num">{{ item.product_price }}</text>
								</view>
								<view class="num-wrap">
									<view class="f22">×{{ item.total_num }}</view>
								</view>
							</view>
							<view class="describe f30" v-if="item.nobuy==true">
								{{item.nobuytext}}
							</view>
							<view class="mt10 tr f28" v-if="item.is_user_grade==true">
								<text class="red">会员折扣价：</text>
								<text class="red">{{item.grade_product_price}}</text>
							</view>
						</view>
					</view>

				</view>
			</view>
			<!--总数-->
			<view class="total-box">
				<view>共{{ OrderData.order_total_num }}件商品，</view>
				<view class="">
					合计：
					<text class="price f30">￥{{ OrderData.order_total_price }}</text>
				</view>
			</view>
		</view>

		<!--其它费用-->
		<view class="buy-checkout">
			<view class="item">
				<text class="key">订单总金额：</text>
				<text class="price">￥{{ OrderData.order_total_price }}</text>
			</view>
			<view class="item" v-if="OrderData.is_coupon">
				<text class="key">优惠券：</text>
				<block v-if="coupon_num > 0">
					<text class="vlaue orange" v-if="OrderData.coupon_id > 0" @click="onTogglePopupCoupon(coupon_list)">-￥{{ OrderData.coupon_money }}</text>
					<text v-else class="vlaue orange" @click="onTogglePopupCoupon(coupon_list)">有{{ coupon_num }}张优惠券可用</text>
				</block>
				<text v-else class="vlaue orange">无优惠券可用</text>
			</view>
			<view class="item" v-if="OrderData.express_price>0">
				<text class="key">配送费用：</text>
				<text class="price">￥{{ OrderData.express_price }}</text>
			</view>
			<view class="item" v-if="OrderData.is_use_points && OrderData.force_points == false && OrderData.points_money > 0">
				<text class="key">可用积分抵扣：</text>
				<view class="">
					<text class="price">-￥{{ OrderData.points_money }}</text>
					<switch style="transform: scale(0.7); margin-right: -10rpx;" @change="onShowPoints" />
				</view>
			</view>
		</view>

		<!--支付方式-->
    <!-- <payOptions :payTypeList="payTypeList" :checkedPayType="pay_type" @click="checkedPayType"></payOptions> -->

	<view class="buy-checkout" v-if="Payment_list && Payment_list.length > 0">
	  <view :class="payment_id === payType.payment_id ? 'item active' : 'item'" v-for="payType in Payment_list" :key="payType.payment_id" @click="changePayType(payType.payment_id)">
	    <view class="d-s-c">
	      <view class="icon-box d-c-c mr10"><image :src="payType.file_url" mode="widthFix" style="width: 50px;"></image></view>
	      <text class="key">{{ payType.name }}</text>
	    </view>
	    <view class="icon-box d-c-c"><span class="icon iconfont icon-xuanze"></span></view>
	  </view>
	</view>

    <!--买家留言-->
		<view class="buyer-message uni-textarea"><textarea class="textarea" v-model="remark" placeholder-style="color:#cccccc;"
			 placeholder="选项:买家留言" /></view>

		<!--底部支付-->
		<view class="foot-pay-btns">
			<view class="price" v-if="!OrderData.force_points">
				¥
				<text class="num">{{ OrderData.order_pay_price }}</text>
			</view>
			<view class="price" v-if="OrderData.force_points">
				<text class="gray9">所需积分</text>
				<text class="num red fb">{{ OrderData.points_num }}</text>
				<template v-if="OrderData.order_pay_price > 0">
					<text>+</text>
					¥
					<text class="num fb">{{ OrderData.order_pay_price }}</text>
				</template>
			</view>
			<button type="primary" @click="SubmitOrder">提交订单</button>
		</view>

		<!--优惠券-->
		<Coupon :isCoupon="isCoupon" :couponList="couponList" @close="closeCouponFunc"></Coupon>
	</view>
</template>

<script>
import MyInfo from './part/my-info';
import StoreInfo from './part/store-info';
import Storage from './part/storage';
import Coupon from './part/coupon';
import { pay } from '@/common/pay.js';
import payOptions from "@/components/order/payOptions";
export default {
	components: {
    MyInfo,
    StoreInfo,
		Coupon,
		Storage,
    payOptions,
	},
	data() {
		return {
			/*是否加载完成*/
			loading: true,
			options: {},
			indicatorDots: true,
			autoplay: true,
			interval: 2000,
			duration: 500,
			tab_type: 0,
			/*商品id*/
			product_id: '',
			/*商品数量*/
			product_num: '',
			/*商品数据*/
			ProductData: [],
			/*订单数据数据*/
			OrderData: [],
			// 是否存在收货地址
			exist_address: false,
			/*默认地址*/
			Address: {
				region: []
			},
			extract_store: [],
			last_extract: {},
			product_sku_id: 0,
			/*配送方式*/
			delivery: 10,
			/*自提店id*/
			store_id: 0,
			/*优惠券id*/
			coupon_id: 0,
			/*是否使用积分*/
			is_use_points: 0,
			linkman: '',
			phone: '',
			remark: '',
			/*支付方式*/
			pay_type: 20,
			payment_id: 0,
			/*是否显示优惠券*/
			isCoupon: false,
			/*优惠券列表*/
			coupon_list: {},
			couponList: [],
			deliverySetting: [],
			/*优惠券数量*/
			coupon_num: 0,
			/*消息模板*/
			temlIds: [],
			settings:{},

			// 支持的支付方式列表
			payTypeList: [],
			Payment_list: [],
			is_submit: 0,
		};
	},
	onLoad(options) {
		let self = this;
		self.options = options;
    uni.$on('selectStoreId', function(store_id) {
      self.store_id = store_id;
    })
	},
	onShow() {
    this.setGlobalColor()
		this.getData();
	},
  computed: {
    active() {
      return (tab_type, value) => {
        if (tab_type === value) {
          return Object.assign(this.setColor(true), {'border-bottom': '2px solid ' + this.getMainColor()})
        }
      }
    },
  },
	methods: {
		/**/
		hasType(e) {
			if (this.deliverySetting.indexOf(e) != -1) {
				return true;
			} else {
				return false;
			}
		},
		changePayType(e){
		  this.payment_id = e
		},
		/*支付方式选择*/
		payTypeFunc(e) {
			this.pay_type = e;
		},
		/*是否使用积分选择*/
		onShowPoints: function(e) {
			let self = this;
			if (e.target.value == true) {
				self.is_use_points = 1;
			} else {
				self.is_use_points = 0;
			}
			self.getData();
		},
		/*选择优惠卷*/
		onTogglePopupCoupon(e) {
			let self = this;
			self.isCoupon = true;
			self.couponList = e;
		},
		/*关闭优惠券*/
		closeCouponFunc(e) {
			let self = this;
			self.coupon_id = e;
			this.isCoupon = false;
			self.getData();
		},
		/*获取数据*/
		getData() {
			let self = this;
			uni.showLoading({
				title: '加载中'
			});

			let callback = function(res) {
				self.OrderData = res.data.orderInfo;
				self.payTypeList = res.data.orderInfo.payTypeList
				self.pay_type = res.data.orderInfo.pay_type
				self.temlIds = res.data.template_arr;
				self.exist_address = self.OrderData.exist_address;
				self.Address = self.OrderData.address;
				self.extract_store = self.OrderData.extract_store;
				self.last_extract = self.OrderData.last_extract;
				self.ProductData = self.OrderData.product_list;
				self.coupon_list = self.OrderData.coupon_list;
				self.coupon_num = Object.keys(self.coupon_list).length;

				self.deliverySetting = res.data.deliveryType;
				self.settings = res.data.settings;

				self.Payment_list = res.data.Payment_list;

				if (self.OrderData.order_pay_price == 0) {
					self.pay_type = 10;
				}
				self.loading = false;
			};

			// 请求的参数
			let params = {
				delivery: self.delivery,
				store_id: self.store_id,
				coupon_id: self.coupon_id,
				is_use_points: self.is_use_points,
				pay_source: self.getPlatform()
			};

			//直接购买
			if (self.options.order_type === 'buy') {
				self._get(
					'order.order/buy',
					Object.assign({}, params, {
						product_id: self.options.product_id,
						product_num: self.options.product_num,
						product_sku_id: self.options.product_sku_id
					}),
					function(res) {
						callback(res);
					},function(res){
						uni.redirectTo({
							url:'/pages/index/index'
						})
					}
				);
			}
			// 购物车结算
			else if (self.options.order_type === 'cart') {
				self._get(
					'order.order/cart',
					Object.assign({}, params, {
						cart_ids: self.options.cart_ids || 0
					}),
					function(res) {
						callback(res);
					}
				);
			}
			// 积分兑换结算
			else if (self.options.order_type == 'points') {
				self._get(
					'plus.points.order/buy',
					Object.assign({}, params, {
						point_product_id: self.options.point_product_id,
						product_sku_id: self.options.product_sku_id,
						point_product_sku_id: self.options.point_product_sku_id,
						product_num: self.options.product_num
					}),
					function(res) {
						callback(res);
					},
					function(res){
						uni.redirectTo({
							url:'/pages/user/index/index'
						})
					}
				);
			}
			// 限时秒杀
			else if (self.options.order_type === 'seckill') {
				params.num = self.options.num;
				self._get(
					'plus.seckill.order/buy',
					Object.assign({}, params, {
						seckill_product_id: self.options.seckill_product_id,
						product_sku_id: self.options.product_sku_id,
						seckill_product_sku_id: self.options.seckill_product_sku_id,
						product_num: self.options.product_num
					}),
					function(res) {
						callback(res);
					},
					function(res){
						uni.redirectTo({
							url:'/pages/user/index/index'
						})
					}
				);
			}
			//砍价
			else if (self.options.order_type === 'bargain') {
				self._get(
					'plus.bargain.order/buy',
					Object.assign({}, params, {
						bargain_product_id: self.options.bargain_product_id,
						product_sku_id: self.options.product_sku_id,
						bargain_product_sku_id: self.options.bargain_product_sku_id,
						bargain_task_id: self.options.bargain_task_id
					}),
					function(res) {
						callback(res);
					},
					function(res){
						uni.redirectTo({
							url:'/pages/user/index/index'
						})
					}
				);
			}
			//拼团
			else if (self.options.order_type === 'assemble') {
				self._get(
					'plus.assemble.order/buy',
					Object.assign({}, params, {
						assemble_product_id: self.options.assemble_product_id,
						product_sku_id: self.options.product_sku_id,
						assemble_product_sku_id: self.options.assemble_product_sku_id,
						product_num: self.options.product_num,
						assemble_bill_id:self.options.assemble_bill_id,
					}),
					function(res) {
						callback(res);
					},
					function(res){
						uni.redirectTo({
							url:'/pages/user/index/index'
						})
					}
				);
			}
		},

		/*选择配送方式*/
		tabFunc(e) {
			this.tab_type = e;
			if (e == 0) {
				this.delivery = 10;
			} else if(e == 1) {
				this.delivery = 20;
			} else if(e ==2) {
				this.delivery = 40;
			}else if(e == 3){
				this.delivery = 30;
			}
 			this.getData();
		},

		/*提交订单*/
		SubmitOrder() {
			let self = this;
			uni.showLoading({
				title: '加载中',
				mask: true,
			});
			if(self.is_submit==1){
				return;
			}
			self.is_submit = 1;
			let _linkman = null;
			let _phone = null;
			if (self.$refs != null) {
				if (self.$refs.getShopinfoData != null) {
					_phone = self.$refs.getShopinfoData.phone;
					_linkman = self.$refs.getShopinfoData.linkman;
				}
			}

			let params = {
				delivery: self.delivery,
				store_id: self.store_id,
				coupon_id: self.coupon_id,
				is_use_points: self.is_use_points,
				phone: _phone,
				linkman: _linkman,
				remark: self.remark,
				pay_type: self.pay_type,
				payment_id: self.payment_id,
				pay_source: self.getPlatform()
			};

			// 创建订单-直接下单
			let url = '';
			if (self.options.order_type === 'buy') {
				url = 'order.order/buy';
				params = Object.assign(params, {
					product_id: self.options.product_id,
					product_num: self.options.product_num,
					product_sku_id: self.options.product_sku_id
				});
			}

			// 创建订单-购物车结算
			if (self.options.order_type === 'cart') {
				url = 'order.order/cart';
				params = Object.assign(params, {
					cart_ids: self.options.cart_ids || 0
				});
			}

			// 创建订单-积分兑换
			if (self.options.order_type === 'points') {
				url = 'plus.points.order/buy';
				params = Object.assign(params, {
					point_product_id: self.options.point_product_id,
					product_sku_id: self.options.product_sku_id,
					point_product_sku_id: self.options.point_product_sku_id,
					product_num: self.options.product_num
				});
			}
			// 创建订单-限时秒杀
			if (self.options.order_type === 'seckill') {
				url = 'plus.seckill.order/buy';
				params.num = self.options.num;
				params = Object.assign(params, {
					seckill_product_id: self.options.seckill_product_id,
					product_sku_id: self.options.product_sku_id,
					seckill_product_sku_id: self.options.seckill_product_sku_id,
					product_num: self.options.product_num
				});
			}
			// 创建订单-砍价
			if (self.options.order_type === 'bargain') {
				url = 'plus.bargain.order/buy';
				params = Object.assign(params, {
					bargain_product_id: self.options.bargain_product_id,
					product_sku_id: self.options.product_sku_id,
					bargain_product_sku_id: self.options.bargain_product_sku_id,
					bargain_task_id: self.options.bargain_task_id
				});
			}

			// 创建订单-限时拼团
			if (self.options.order_type === 'assemble') {
				url = 'plus.assemble.order/buy';
				params = Object.assign(params, {
					assemble_product_id: self.options.assemble_product_id,
					product_sku_id: self.options.product_sku_id,
					assemble_product_sku_id: self.options.assemble_product_sku_id,
					assemble_bill_id: self.options.assemble_bill_id,
					product_num: self.options.product_num,
				});
			}
			let callback = function(){
				self._post(url, params, function(result) {
					if (result.data.pay_type != 50) {
						self.is_submit = 0;
					}
					pay(result, self);
				});
			};

			self.subMessage(self.temlIds, callback);
		},
    // 选择支付方式触发
    checkedPayType(e){
      this.pay_type = e
    },

  }
};
</script>

<style lang="scss" scoped>
.confirm-tips{
	padding: 0 15px;
	border-bottom: 1px solid #EEEEEE;
	max-height: 200rpx;
	overflow: auto;
}
.wrap {
	padding-bottom: 90rpx;
}

.text-disabled{
	color: #c6c6c6;
}
.nobuy{
	color: #ff0000;
}
</style>
